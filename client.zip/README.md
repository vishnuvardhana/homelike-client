### installation & run
1. start the server in the `../server` folder
2. start the client:
    - npm i
    - npm start


#Tasks

## Changes or improvements
`All the views which do not have their own state is moved into components/ following redux convention of keeping dumb and containers separately,please note some files names are changed for convention`

1. App.js 
    1. Changed `/apartments/:apartmentId` to `/apartment/:apartmentId` to ensure route name is matching what the page is showing

2. HomeView.js
    1. All fetch calls needed during component load changed from lifecycle hook `componentWillMount` to 'componentDidMount` 

3. ApartmentAmentityView.js (renamed as ApartmentAmentityComponent inside components folder)
    1. .map function was used earlier to return list of amentities replace it with `forEach`, we are returning amenities array after forEach anyway

4. ApartmentView.js
    1. All fetch calls needed during component load changed from lifecycle hook `componentWillMount` to 'componentDidMount` 
    2. ApartmentView JSX was mostly duplicate of ApartmentTileView except the limit and <a> tag combined htmls inside ApartmentTitleView (renamed as compoents/DisplayApartmentComponent )

5. Constants
    1. added variable like `allApartmentAttributes` to make sure we do not repeat same query params everywhere 
    2. Generalized some queries keeping reusability in mind

6. ApartmentListAction (renamed as homeViewActions)
    1. Renamed this file as homeActions to follow naming conventions of redux
    2. using `apartmentAttrsWithDetails` const variable to reuse in the future

7. ApartmentTitleView (renamed and moved into compoents/DisplayApartmentComponent)
    1. used react-routers `Link` instead of  <a> (as a convention)
    2. Created a component called <DisplayApartmentAttributes/> which is called based on tile/apartment based on limit prop. 

8. (new code not an improvement from the given code)Created Sharable components like eg. CheckboxComponent, RangeComponent and DropdownComponent for reusability


## Add webpack
  1. please check ./config folder for webpack
  2. unmounted react-scripts to achieve this 

## Add information about owner to apartment view page
   1. Owner email is added in the apartmentView page , was not able to get profile details (query was returning null for profile in grahiql) so only showing email for now.

## Add new page "Locations", show the apartments filtered by location
   1. visit 'http://localhost:3000/locations' to filter apartments by locations

## Add new page "search page", provide abilities to search by location and filter by [size, price, amenities, details, services]
   1. visit 'http://localhost:3000/search' 