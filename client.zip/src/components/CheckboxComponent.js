import React from 'react';

const checkBoxStyle = {
    cursor: 'pointer',
}

export default class CheckboxComponent extends React.Component {
 
  render() {
    let selectedValues = this.props.selectedValues;

    const onClickCB = (event)=>{
        let changedCbValueIndex = -1;
        const checkBoxValue = event.target.value;

        if(event.target.checked) {
            // adding selected filter value to the selected array
            selectedValues.push(event.target.value);
        } else {
            changedCbValueIndex = selectedValues.indexOf(checkBoxValue);

            if(changedCbValueIndex > -1) {
                // removing selected fitler value to the selected array
                selectedValues.splice(changedCbValueIndex, 1);  
            }
        }

        this.props.updateFilter(this.props.label, selectedValues);
    };
   
    return (
         <div className="form-group">
           <label style={{textTransform: 'capitalize'}}> {this.props.label} </label>
           <br/>
           <br/>
           
           {
               this.props.checkBoxValues.map((checkBox, index)=>{
                   const markAsSelected = selectedValues.indexOf(checkBox) > -1 ? true : false;

                    return (
                        <div className="checkbox col-6" key = {index} >
                            <label><input type="checkbox" value={checkBox} style={checkBoxStyle} onClick = {onClickCB} defaultChecked = {markAsSelected}/>{checkBox}</label>
                        </div>
                    )
                })
           } 
        </div>
    );
  }
}
