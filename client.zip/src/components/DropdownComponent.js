import React from 'react';

export default class DropdownComponent extends React.Component {
  render() {
    const selectOnChange = (event)=>{
      this.props.ddOnChange(event.target.selectedIndex)
    };

    return (
        <select className ={`${this.props.widthClass ? this.props.widthClass + ' ' : ''}form-control`} onChange = {selectOnChange}>
          {
            this.props.ddValues.map((item, index)=>{
              return (<option key={index} value={item._id}> {item.title}</option>)
            })
          }
        </select>
      
      
      ) 
  }
}
