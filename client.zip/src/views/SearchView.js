import React from 'react';
import {connect} from 'react-redux';
import {fetchAllLocations, searchApartmentsUsingLocation} from './../actions/searchActions';
import SharedComponents from "../components";
import {listOfFilters} from '../constants';

const leftSideBar = {
  height: '80vh',
  overflow: 'auto',
  padding: '15px',
};

class SearchView extends React.Component {
  constructor(props) {
    super(props);

    this.filters = {
      size: -1,
      price: -1,
      rooms: -1,
      floor: -1,
      bathrooms: -1,
      bedrooms: -1,
      amenities: [],
      services: [],
    };

    this.searchBoxRef = React.createRef();

    this.searchLocation = this
      .searchLocation
      .bind(this);

    this.filterChangeCB = this
      .filterChangeCB
      .bind(this);
    this.getAllLocationIds = this
      .getAllLocationIds
      .bind(this);
  }

  componentDidMount() {
    this
      .props
      .fetchAllLocations();
  }

  getAllLocationIds(text) {
    const searchText = new RegExp(text, "i");
    let searchIds = [];

    this
      .props
      .locationList
      .items
      .forEach((item) => {
        if (item.title.match(searchText)) {
          searchIds.push(item._id);
        }
      });

    return searchIds;
  }

  searchLocation(event) {
    try {
      const searchIds = this.getAllLocationIds(event.target.value);

      if (!searchIds.length || !event.target.value) {
        this
          .props
          .searchApartmentsUsingLocation([null]);
        return;
      }

      this
        .props
        .searchApartmentsUsingLocation(searchIds, this.filters.price > -1
          ? this.filters
          : undefined);
    } catch (e) {
      console.log(e);
    }

  }

  filterChangeCB(name, value) {
    this.filters[name] = value;
    this
      .props
      .searchApartmentsUsingLocation(this.getAllLocationIds(this.searchBoxRef.current.value), this.filters);
  }

  render() {
    const loader = <div>Loading...</div>;
    let {locationList, filteredApartments} = this.props;
    const hasUserTypedSomething = !this.searchBoxRef.current || !this.searchBoxRef.current.value;

    const state = this.filters;

    if (!Object.keys(locationList).length) {
      return loader;
    }

    return (

      <div className="container-list container-fluid clearfix">
        <div className="form-group">
          <input
            type="text"
            className="form-control col-12"
            id="search-box"
            placeholder="search using location name"
            onChange={this.searchLocation}
            ref={this.searchBoxRef}/>
        </div>
        <br/>
        <br/> {!hasUserTypedSomething
          ? <div className="col-3 float-left"  style={leftSideBar}>
             
              {listOfFilters.map((filter, index) => {
                let filterDom = null;

                switch (filter.type) {
                  case 'slider':
                    // making sure to set default value of filters to be max
                    state[filter.filterName] = state[filter.filterName] < 0
                      ? filter.maxValue
                      : state[filter.filterName];

                    filterDom = <SharedComponents.RangeComponent
                      label={filter.filterName}
                      min={filter.minValue}
                      max={filter.maxValue}
                      value={state[filter.filterName]}
                      updateSlider={this.filterChangeCB}
                      measurement={filter.measurement}
                      step={filter.step}/>

                    break;
                  case 'checkbox':
                    // passing selected filters to make sure its part of the rerender
                    state[filter.filterName] = state[filter.filterName].length === 0
                      ? []
                      : state[filter.filterName];

                    filterDom = <SharedComponents.CheckboxComponent
                      label={filter.filterName}
                      checkBoxValues={filter.ddValues}
                      selectedValues = {state[filter.filterName]}
                      updateFilter = {this.filterChangeCB}/>
                    
                    break;
                  default:
                    return filterDom;
                }

                return (
                  <div
                    key={index}
                    className="filter"
                    >
                    {filterDom}
                    <hr/>
                  </div>
                )
              })}
              </div>
          : null}
        <div className="col-9 float-left">
          <div className="view-apartment-list" style ={{'justifyContent': 'flex-start'}}>
            {!filteredApartments && this.searchBoxRef.current.value
              ? loader
              : filteredApartments.items
                ? filteredApartments
                  .items
                  .map((item, index) => (
                    <SharedComponents.DisplayApartmentComponent key={index} apartment={item}/>
                  ))
                : null}

            {hasUserTypedSomething
              ? <div>Type location name to get apartments</div>
              : null}
            {!hasUserTypedSomething && (!filteredApartments.items || !filteredApartments.items.length)
              ? <div>No valid apartments found! Try different location name or change filter values!</div>
              : null}
          </div>
        </div>
      </div>
    )
  }
}

const mapStateToProps = state => ({locationList: state.searchPageState.locations, filteredApartments: state.searchPageState.filteredApartments});

export default connect(mapStateToProps, {fetchAllLocations, searchApartmentsUsingLocation})(SearchView)
