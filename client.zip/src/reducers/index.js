import {combineReducers} from 'redux';
import apartmentsListReducer from './apartmentsListReducer';
import apartmentReducer from './apartmentReducer';
import  locationsReducer from './locationsReducer';
import searchReducer from './searchReducer';


export default combineReducers({
    apartmentsList: apartmentsListReducer,
    apartmentItem: apartmentReducer,
    locationState: locationsReducer,
    searchPageState: searchReducer,
})
