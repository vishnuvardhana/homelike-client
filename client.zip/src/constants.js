const constants = {
};

export const allApartmentAttributes = `{
    items {
      _id
      owner {
      _id
        email
      } 
      title
      location {
        title
        _id
      }
      size
      price
      amenities
      images
    }
}`;

export const apartmentAttrsWithDetails = `{
    _id
    owner {
    _id
      email
    } 
    title
    location {
      title
      _id
    }
    size
    price
    amenities
    images
    services
    details {
      rooms
      floor
      bathrooms
      bedrooms
    }
  
}`;

export const FETCH_APARTMENTS_FOR_LOCATION_QUERY = (_id) => { 
    return(`
          {
            
            apartments(location: "${_id}")  {items ${apartmentAttrsWithDetails}}
            
          }`);
};

export const FETCH_LOCATIONS_QUERY = () => {
    return (`
      {
          locations {
            items {
              title
              _id
            }
          }
        
    }`);
};

export const  listOfFilters = [
  {
    filterName: 'size',
    type: 'slider',
    minValue: 0,
    maxValue: 100,
    measurement: 'm²',
    step: 10,
  },
  {
    filterName: 'price',
    type: 'slider',
    minValue: 0,
    maxValue: 5000,
    measurement: '$',
    step: 250,
  },
  {
    filterName: 'rooms',
    type: 'slider',
    minValue: 1,
    maxValue: 10,
    measurement: null,
    step: 1,
  },
  {
    filterName: 'floor',
    type: 'slider',
    minValue: 1,
    maxValue: 20,
    measurement: null,
    step: 1,
  },
  {
    filterName: 'bathrooms',
    type: 'slider',
    minValue: 1,
    maxValue: 10,
    measurement: null,
    step: 1,
  },
  {
    filterName: 'bedrooms',
    type: 'slider',
    minValue: 1,
    maxValue: 10,
    measurement: null,
    step: 1,
  },
  {
    filterName: 'amenities',
    type: 'checkbox',
    ddValues: [],
  },
  {
    filterName: 'services',
    type: 'checkbox',
    ddValues: [],
  }
];

export default constants;
