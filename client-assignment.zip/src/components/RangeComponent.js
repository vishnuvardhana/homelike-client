import React from 'react';

export default class RangeComponent extends React.Component {
  render() {
    const onChange = (event)=>{
        this.props.updateSlider(this.props.label, Number(event.target.value));
    };
   
    return (
        <div className="form-group">
            <label style={{textTransform: 'capitalize'}}> {this.props.label} ({this.props.measurement ? `${this.props.measurement} ` : ''}{this.props.value})</label>
            <br/>
            <br/>
            <input className="slider" type="range" name="points" min={this.props.min.toString()} max={this.props.max.toString()} value = {this.props.value.toString()} onChange = {onChange} step = {this.props.step}/>
            
        </div>
    );
  }
}
