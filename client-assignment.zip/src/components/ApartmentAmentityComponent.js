import React from 'react';

export default class ApartmentAmentityComponent extends React.Component {
  render() {
    let {apartment, limit = 3} = this.props;
    let amentities = [];
    
    // forEach instead of map since we are returning amentities array
    apartment.amenities.forEach((item, index) => {
      if (index < limit) {
        amentities.push(<span className="_1h9l4w0vvX6d56ZnJ3NLod" key = {index} ><i></i><span>{item}</span></span>);
      }
    });

    return amentities
  }
}
