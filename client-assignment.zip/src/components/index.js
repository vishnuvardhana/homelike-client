import DropdownComponent from './DropdownComponent';
import RangeComponent from './RangeComponent';
import CheckboxComponent from './CheckboxComponent';
import DisplayApartmentComponent from './DisplayApartmentComponent';

const SharedComponents = {
    DropdownComponent: DropdownComponent,
    RangeComponent: RangeComponent,
    CheckboxComponent: CheckboxComponent,
    DisplayApartmentComponent: DisplayApartmentComponent,
};

export default SharedComponents;