import React from 'react';
import {Link } from "react-router-dom";
import DisplayApartmentAttributes from "./DisplayApartmentAttributes";

export default class DisplayApartmentComponent extends React.Component {

  render() {
    const {apartment, limit} = this.props;
    const url = '/apartment/' + apartment._id;

    return (
      <div className="view-apartment-item">
        <div className="view-apartment-item-content">
          {
            limit ?  
            <DisplayApartmentAttributes apartment = {apartment} limit = {limit}/>
            : 
            <Link to={url} target="_blank">
              <DisplayApartmentAttributes apartment = {apartment} limit = {limit}></DisplayApartmentAttributes>
            </Link>
          }
        </div>
      </div>
    )
  }
}