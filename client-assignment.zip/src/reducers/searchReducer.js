import {FETCH_ALL_LOCATIONS, FETCH_ALL_SEARCHED_LOCATION_APARTMENTS} from './../actions/types';

const initialState = {
   locations: {},
   filteredApartments: [],
};


export default (state = initialState, action) => {
    switch (action.type) {
        case FETCH_ALL_LOCATIONS:
            return {
                ...state,
                locations: action.payload.locations
            };
        case FETCH_ALL_SEARCHED_LOCATION_APARTMENTS:
            return {
                ...state,
                filteredApartments: action.payload.apartments,
            }
        default:
            return state;
    }
}
