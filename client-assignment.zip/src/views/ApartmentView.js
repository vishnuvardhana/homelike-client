import React from 'react';
import {fetchApartment} from "../actions/apartmentActions";
import {connect} from "react-redux";
import SharedComponents from '../components';

export class ApartmentView extends React.Component {
  // componentDidMount instead of componentWillMount
  componentDidMount(){
    const { match: { params } } = this.props;
    const { apartmentId } = params;
    this.props.fetchApartment(apartmentId);
  }

  render() {
    const { apartment } = this.props;
  
    if(apartment.title) {
      document.title = apartment.title;
    }

    if (!Object.keys(apartment).length) {
      return <div>Loading...</div>
    }
   

    return (
      <div className='container-fl clearfix'>
        <div className='col-12'>
          <div className='view-apartment'>
            <SharedComponents.DisplayApartmentComponent apartment={apartment} limit= {20}/>
        </div>
      </div>
    </div>
    )
  }
}

const mapStateToProps = state => ({
  apartment: state.apartmentItem.apartment
});

export default connect(mapStateToProps, {fetchApartment})(ApartmentView)
