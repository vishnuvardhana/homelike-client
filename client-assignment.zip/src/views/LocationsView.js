import React from 'react';
import {connect} from 'react-redux';
import {fetchAllLocations, fetchAllApartmentsForLocation} from '../actions/locationsActions';
import SharedComponents from '../components';

class LocationsView extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      selectedLocationIndex: 0
    };

    this.locationChange = this
      .locationChange
      .bind(this);
  }

  componentDidMount() {
    this
      .props
      .fetchAllLocations();
  }

  locationChange(index) {
    try {
      this
        .props
        .fetchAllApartmentsForLocation(this.props.locationList.items[index]._id);
    } catch (e) {
      console.log(e);
    }

  }

  render() {
    let {locationList, filteredApartments} = this.props;

    const loader = <div>Loading...</div>;

    if (!Object.keys(locationList).length) {
      return loader;
    }

    if (!Object.keys(filteredApartments).length) {
      this.locationChange(0);
      return loader;
    }

    return (

      <div className="container-list container-lg clearfix">
        Locations
        <SharedComponents.DropdownComponent
          widthClass={'col-12'}
          ddValues={locationList.items}
          ddOnChange={this.locationChange}/>
        <br/>
        <br/>
        <div className="col-12 float-left">
          <div
            className="view-apartment-list"
            style={{
            'justifyContent': 'space-evenly'
          }}>
            {/* removing key as prop */}
            {filteredApartments.items.length
              ? filteredApartments
                .items
                .map((item, index) => (<SharedComponents.DisplayApartmentComponent key={index} apartment={item}/>))
              : <h4>{`No Apartments found for this location.. Try Another Location!`}</h4>}
          </div>
        </div>
      </div>
    )
  }
}

const mapStateToProps = state => ({locationList: state.locationState.locations, filteredApartments: state.locationState.filteredApartments});

export default connect(mapStateToProps, {fetchAllLocations, fetchAllApartmentsForLocation})(LocationsView)
