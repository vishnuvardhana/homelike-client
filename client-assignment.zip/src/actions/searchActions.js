import {FETCH_ALL_LOCATIONS, FETCH_ALL_SEARCHED_LOCATION_APARTMENTS} from "./types";
import gql from "graphql-tag";
import client from './../ApolloClient'
import {FETCH_APARTMENTS_FOR_LOCATION_QUERY, FETCH_LOCATIONS_QUERY, listOfFilters} from '../constants';

// to find index of amenities and services from listOfFilters
const findFilterIndex = (filterName) => {
  return listOfFilters.findIndex((filter) => {
    return (filter.filterName === filterName);
  });
};

const amenitiesIndex = findFilterIndex('amenities');
const servicesIndex = findFilterIndex('services');

/**
 * Fetch all locations
 */
export const fetchAllLocations = () => dispatch => {
  client.query({query: gql `${FETCH_LOCATIONS_QUERY()}`}).then(locations => dispatch({type: FETCH_ALL_LOCATIONS, payload: locations.data}));
};

/**
 * get all apartments based on locationId
 * @param {*} locationIds  _id(s) of searched location(s)
 */
export const searchApartmentsUsingLocation = (locationIds, selectedFilters) => dispatch => {
  let promiseArray = [];

  // for filtering amenities and services
  const unionFilter = (items, propertyName) => {
    let numberOfSelected = selectedFilters[propertyName].length;

    // matching conditions eg. if ['television', 'elevator'] are selected it will
    // decrement the value in each iteration -numberOfSelected = 0 means all the
    // selected values are part of the apartment else either one or many conditions
    // are not matching
    selectedFilters[propertyName].forEach((item) => {
      if (items.indexOf(item) > -1) {
        numberOfSelected -= 1;
      }

    });

    if (numberOfSelected === 0) {
      return true;
    }

    return false;
  };

  // ideally would have to happen at the backed, for now implementing filter on the
  // produced result form the gql query
  const passingAllFilters = (item) => {
    if (item.price > selectedFilters.price) {
      return false;
    }

    if (item.size > selectedFilters.size) {
      return false;
    }

    if (item.details.rooms > selectedFilters.rooms) {
      return false;
    }

    if (item.details.floor > selectedFilters.floor) {
      return false;
    }

    if (item.details.bathrooms > selectedFilters.bathrooms) {
      return false;
    }

    if (item.details.bedrooms > selectedFilters.bedrooms) {
      return false;
    }

    // by default all are included, only when filtered we need to filter on this
    // propery
    if (selectedFilters.amenities.length > 0 && !unionFilter(item.amenities, 'amenities')) {
      return false;
    }

    if (selectedFilters.services.length > 0 && !unionFilter(item.services, 'services')) {
      return false;
    }

    return true;
  };

  // to make sure we get apartments for all matching locations eg. berlin and
  // Cologne if user types 'l'
  locationIds.forEach((_id, index) => {
    promiseArray.push(new Promise((resolve) => {
      client.query({query: gql `${FETCH_APARTMENTS_FOR_LOCATION_QUERY(_id)}`}).then((response) => {
        resolve(response.data.apartments.items);
      });
    }));
  });

  // once all promises are resolved we combine apartments
  Promise
    .all(promiseArray)
    .then((allApartments) => {
      let combinedApartments = [];

      let filters = {
        amenityFilter: [],
        services: [],
        size: [],
        price: []
      };

      allApartments.forEach((apartment) => {
        apartment.forEach((item) => {
          filters
            .amenityFilter
            .push(item.amenities);
          filters
            .services
            .push(item.services);

          if (!selectedFilters || passingAllFilters(item)) {
            combinedApartments.push(item);
          }
        });
      });

      // considering other filters are numerical storing only amenities and services
      // eliminate duplicates incase we end up in zero results we still need to show
      // an non empty filter values so checking combinedApartments
      if (combinedApartments.length > 0) {
        listOfFilters[amenitiesIndex].ddValues = Array.from(new Set(filters.amenityFilter.flat()));
        listOfFilters[servicesIndex].ddValues = Array.from(new Set(filters.services.flat()));
      }

      dispatch({
        type: FETCH_ALL_SEARCHED_LOCATION_APARTMENTS,
        payload: {
          apartments: {
            items: combinedApartments
          }
        }
      })
    });
};
