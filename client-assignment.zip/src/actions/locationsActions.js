import {FETCH_ALL_LOCATIONS, FETCH_ALL_LOCATION_APARTMENTS} from "./types";
import gql from "graphql-tag";
import client from '../ApolloClient'
import {FETCH_APARTMENTS_FOR_LOCATION_QUERY, FETCH_LOCATIONS_QUERY} from '../constants'

/**
 * Fetch all locations
 */
export const fetchAllLocations = () => dispatch => {
  client.query({
    query: gql`${FETCH_LOCATIONS_QUERY()}`,
})
.then(locations => dispatch({
  type: FETCH_ALL_LOCATIONS,
  payload: locations.data
}));
};

/**
 * Fetch all aparts against locationId
 * @param {*} _id  locationId
 */
export const fetchAllApartmentsForLocation = (_id) => dispatch => {
  client.query({
    query: gql`${FETCH_APARTMENTS_FOR_LOCATION_QUERY(_id)}`,
  })
  .then(apartments => dispatch({
    type: FETCH_ALL_LOCATION_APARTMENTS,
    payload: apartments.data
  }));
};