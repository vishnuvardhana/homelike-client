import {FETCH_APARTMENTS_LIST} from "./types";
import gql from "graphql-tag";
import client from './../ApolloClient'
import {allApartmentAttributes} from '../constants'

export const fetchApartmentsList = () => dispatch => {
  client.query({
    query: gql`
    {
      apartments(active: true) ${allApartmentAttributes}
    }`
})
.then(apartments => dispatch({
  type: FETCH_APARTMENTS_LIST,
  payload: apartments.data
}));
};


